# 🐕 Happy Dog — Cyber Runner

Un juego de runner cyberpunk donde un perro corre por las calles de una ciudad neón, atrapa huesos y esquiva obstáculos. Sin instalación, sin antivirus, funciona en cualquier PC o Mac.

---

## 🎮 Cómo jugar

### Windows
1. Descarga o clona este repositorio
2. Haz **doble click** en `Jugar_Windows.bat`
3. El juego abre como ventana de app (sin barras del navegador)

### Mac
1. Descarga o clona este repositorio
2. Abre la Terminal en la carpeta del juego
3. Ejecuta:
   ```bash
   chmod +x Jugar_Mac.sh && ./Jugar_Mac.sh
   ```
4. O simplemente abre `HappyDog.html` con tu navegador

### Cualquier sistema (alternativa directa)
Abre el archivo `HappyDog.html` directamente en Chrome, Edge, Firefox o Safari.

---

## 🕹️ Controles

| Acción | Control |
|--------|---------|
| Saltar | `Barra espaciadora` |
| Saltar (móvil/touch) | Tap en la pantalla |
| Navegar menú | `↑ ↓` / `← →` |
| Confirmar | `Espacio` o `Enter` |
| Volver | `Escape` |

---

## ⚙️ Dificultades

| Modo | Velocidad | Obstáculos |
|------|-----------|------------|
| EASY | Reducida (-18%) | Pocos |
| NORMAL | Estándar | Medio |
| HARD | Alta (+45%) | Muchos |

---

## 🏆 Mecánicas

- Atrapa **huesos** para sumar puntos
- Esquiva **hidrantes** y **pájaros** — cada golpe resta una vida
- Cada **20 puntos** la velocidad aumenta un 15%
- Cada **50 puntos** recuperas una vida ❤️
- Tienes **5 vidas** en total — el juego es infinito hasta perderlas todas

---

## 🛠️ Tecnología

- HTML5 + Canvas — sin dependencias, sin instalación
- Sonidos 8-bit generados con Web Audio API
- Música de fondo incluida en el archivo
- Funciona offline 100%

---

## 📥 Descarga rápida

Ve a [Releases](../../releases) para descargar la última versión como archivo zip.

---

## 📄 Licencia

MIT — libre para usar, modificar y compartir.
