@echo off
SET FILE=%~dp0HappyDog.html

:: Intentar con Chrome
SET CHROME="C:\Program Files\Google\Chrome\Application\chrome.exe"
SET CHROME2="C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"

IF EXIST %CHROME% (
    %CHROME% --app="file:///%FILE:\=/%"  --window-size=840,400 --window-position=100,100
    GOTO FIN
)
IF EXIST %CHROME2% (
    %CHROME2% --app="file:///%FILE:\=/%"  --window-size=840,400 --window-position=100,100
    GOTO FIN
)

:: Intentar con Edge (viene incluido en Windows 10/11)
SET EDGE="C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
IF EXIST %EDGE% (
    %EDGE% --app="file:///%FILE:\=/%"  --window-size=840,400 --window-position=100,100
    GOTO FIN
)

:: Si no encuentra ninguno, abrir en navegador por defecto
echo Abriendo en navegador por defecto...
start "" "%FILE%"

:FIN
