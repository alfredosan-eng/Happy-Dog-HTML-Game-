#!/bin/bash
DIR="$(cd "$(dirname "$0")"; pwd)"
FILE="$DIR/HappyDog.html"

CHROME="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
CHROMIUM="/Applications/Chromium.app/Contents/MacOS/Chromium"

if [ -f "$CHROME" ]; then
    "$CHROME" --app="file://$FILE" --window-size=840,400 &
elif [ -f "$CHROMIUM" ]; then
    "$CHROMIUM" --app="file://$FILE" --window-size=840,400 &
else
    open "$FILE"
fi
