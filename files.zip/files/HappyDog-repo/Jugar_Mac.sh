#!/bin/bash
DIR="$(cd "$(dirname "$0")"; pwd)"
FILE="$DIR/HappyDog.html"

# Intentar con Chrome
CHROME="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
if [ -f "$CHROME" ]; then
    "$CHROME" --app="file://$FILE" --window-size=840,400 &
    exit 0
fi

# Intentar con Chromium
CHROMIUM="/Applications/Chromium.app/Contents/MacOS/Chromium"
if [ -f "$CHROMIUM" ]; then
    "$CHROMIUM" --app="file://$FILE" --window-size=840,400 &
    exit 0
fi

# Si no hay Chrome, abrir con Safari
open "$FILE"

